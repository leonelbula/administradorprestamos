
<?php $__env->startSection('title'); ?>
<?php echo e($title); ?>   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <a href="<?php echo e(route('cliente.index')); ?>" class="btn btn-success btn-sm btn-icon-split">      
            <span class="text">Cancelar</span>
        </a>
    </div>
    <div class="card-body">
        <div class="col-lg-7">
            <div class="p-2">
                <form class="user" method="POST" action="<?php echo e(route('cliente.save')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="text" class="form-control " name="fullname" id="fullname" value="<?php echo e(old('fullname')); ?>" placeholder="Nombre completo">
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control " name="identification" id="identification" value="<?php echo e(old('identification')); ?>" placeholder="Identificacion">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control " name="city" id="city" value="<?php echo e(old('city')); ?>" placeholder="Ciudad">
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control " name="direction" id="direction" value="<?php echo e(old('direction')); ?>" placeholder="Direccion">
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="phone" class="form-control " name="phone" id="phone" value="<?php echo e(old('phone')); ?>" placeholder="Telefono">
                        </div>
                        <div class="col-sm-6">
                            <input type="email" class="form-control " name="email" id="email" value="<?php echo e(old('email')); ?>"  placeholder="Email">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Guardar</button>             
                    
                </form>               
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\administradorprestamos\resources\views/customer/create.blade.php ENDPATH**/ ?>