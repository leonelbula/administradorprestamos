
<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?php echo e(route('cliente.index')); ?>" class="btn btn-success btn-sm btn-icon-split">
                <span class="text">Cancelar</span>
            </a>
        </div>
        <div class="card-body">
            <div class="col-lg-7">
                <div class="p-2">
                    <form class="user" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <?php if($errors->has('name')): ?>
                                <div class="alert alert-danger"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                            <input type="text" class="form-control " name="name" id="name"
                                value="<?php echo e(old('name')); ?>" placeholder="Nombre completo">
                        </div>
                        <div class="form-group">
                            <?php if($errors->has('email')): ?>
                                <div class="alert alert-danger"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                            <input type="email" class="form-control " name="email" id="email"
                                value="<?php echo e(old('email')); ?>" placeholder="Email">
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <?php if($errors->has('type')): ?>
                                <div class="alert alert-danger"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                                <select name="type" id="type" class="form-control ">
                                    <option value="cobrador">Cobrador</option>
                                    <option value="administrador">Administrador</option>
                                </select>
                            </div>
                            <div class="col-sm-6 mb-3 mb-sm-0">
                                <input type="password" class="form-control " name="password" id="password"
                                    value="<?php echo e(old('password')); ?>" placeholder="Contraseña">
                            </div>
                        </div>


                        <button type="submit" class="btn btn-primary btn-block">Guardar</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\administradorprestamos\resources\views/personalInfomation/create.blade.php ENDPATH**/ ?>