
<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?php echo e(route('amountuser.report')); ?>" class="btn btn-success btn-sm btn-icon-split">
                <span class="text">Volver</span>
            </a>
        </div>
        <div class="card-body">
            <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-9">
                    <div class="p-2">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(strtoupper($value->user->name)); ?> &nbsp;&nbsp;
                                <spam class="text-success"> Fecha:</spam>
                                <?php echo e($value->date); ?></h6>
                        </div>
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Observacion</h6>
                        </div>
                        <ul>
                            <li><?php echo e($value->details); ?></li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <hr>
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Informacion</h6>
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>codigo</th>
                                        <th>Valor</th>
                                        <th>Saldo</th>
                                        <th>Fecha</th>

                                    </tr>
                                </thead>
                                <tbody>

                                    <tr>
                                        <td><?php echo e($value->id); ?></td>
                                        <td><?php echo e($value->amount); ?></td>
                                        <td>
                                            <?php if($value->amount_difference < 0): ?>
                                                <spam class="text-danger">
                                                    <?php echo e(number_format($value->amount_difference, 0, '', '.')); ?></spam>
                                            <?php else: ?>
                                                <spam class="text-success">
                                                    <?php echo e(number_format($value->amount_difference, 0, '', '.')); ?></spam>
                                            <?php endif; ?>

                                        <td><?php echo e($value->date); ?></td>
                                    </tr>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\administradorprestamos\resources\views/amountuser/showtotalclose.blade.php ENDPATH**/ ?>