
<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('buttom'); ?>
    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
            class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?php echo e(route('amounuser.index')); ?>" class="btn btn-success btn-sm btn-icon-split">
                <span class="text">Volver</span>
            </a>
            <a href="<?php echo e(route('amounuser.index')); ?>" class="btn btn-success btn-sm btn-icon-split">
                <span class="text">Total Ingresado</span>
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Fecha</th>
                            <th>Total</th>
                            <th>Diferencia</th>

                            <th>Aciones</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $totalValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key); ?></td>
                                <td><?php echo e($value->date); ?></td>
                                <td><?php echo e(number_format($value->total, 0, '', '.')); ?></td>
                                <td><?php echo e(number_format($value->total_difference, 0, '', '.')); ?></td>

                                <td>
                                    <a href="<?php echo e(route('amountuser.showtotalclose', $value->date)); ?>"
                                        class="btn btn-info btn-sm">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\administradorprestamos\resources\views/amountuser/totalclose.blade.php ENDPATH**/ ?>