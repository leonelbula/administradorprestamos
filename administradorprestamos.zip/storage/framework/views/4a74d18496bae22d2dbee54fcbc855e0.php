
<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php date_default_timezone_set('America/Bogota'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?php echo e(route('bill.index')); ?>" class="btn btn-success btn-sm btn-icon-split">
                <span class="text">Cancelar</span>
            </a>

        </div>
        <div class="card-body">
            <div class="col-lg-7">
                <div class="p-2">
                    <form class="user" method="POST" action="<?php echo e(route('bill.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <input type="date" class="form-control " name="date" id="date"
                                    value="<?php echo e(date('Y-m-d')); ?>" placeholder="" required>
                            </div>
                            <div class="col-sm-6 mb-3 mb-sm-0">
                                <input type="number" class="form-control " name="amount" id="amount"
                                    value="<?php echo e(old('amount')); ?>" placeholder="Valor" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <textarea name="description" class="form-control " id="description" cols="3" rows="5" required></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary btn-block" id="btnSave">Registrar gasto</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php if(session('fail')): ?>
        <script>
            Swal.fire({
                title: 'Error',
                text: '<?php echo e(session('fail')); ?>',
                icon: 'error',
                confirmButtonText: 'Cerrar'
            })
        </script>
    <?php elseif(session('success')): ?>
        <script>
            Swal.fire({
                title: 'Informacion guardada',
                text: '<?php echo e(session('success')); ?>',
                icon: 'success',
                confirmButtonText: 'Cerrar'
            })
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\administradorprestamos\resources\views/bill/create.blade.php ENDPATH**/ ?>