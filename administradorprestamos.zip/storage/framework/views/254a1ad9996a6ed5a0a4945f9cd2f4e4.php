
<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?php echo e(route('cliente.index')); ?>" class="btn btn-success btn-sm btn-icon-split">
                <span class="text">Volver</span>
            </a>
        </div>
        <div class="card-body">
            <div class="col-lg-9">
                <div class="p-2">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary"><?php echo e(strtoupper($customer->fullname)); ?></h6>
                    </div>
                </div>
                <div class="card-body">
                    <ul>
                        <li><?php echo e($customer->identification); ?></li>
                        <li><?php echo e($customer->direction); ?></li>
                        <li><?php echo e($customer->phone); ?></li>
                        <li><?php echo e($customer->city); ?></li>
                    </ul>
                    <hr>
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Cobrador Asignado</h6>
                    </div>
                    <ul>
                        <li><?php echo e($customer->assignacion->user->name); ?></li>
                    </ul>
                    <hr>
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Informacion de Prestamos</h6>
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Entregado</th>
                                    <th>Valor</th>
                                    <th>Saldo</th>
                                    <th>Cuotas Pendiente</th>
                                    <th>Fecha Vencimento</th>
                                    <th>Aciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $customer->credit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($credit->created_at); ?></td>
                                        <td><?php echo e($credit->amount); ?></td>
                                        <td><?php echo e($credit->balance); ?></td>
                                        <td><?php echo e($credit->quota_number_pendieng); ?></td>
                                        <td><?php echo e($credit->expiration_date); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('cliente.show', $customer)); ?>" class="btn btn-info btn-sm">
                                                <i class="fas fa-eye">Renovar</i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\administradorprestamos\resources\views/customer/show.blade.php ENDPATH**/ ?>