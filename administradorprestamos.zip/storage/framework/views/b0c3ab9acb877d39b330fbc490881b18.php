
<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php date_default_timezone_set('America/Bogota'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?php echo e(route('cliente.index')); ?>" class="btn btn-success btn-sm btn-icon-split">
                <span class="text">Cancelar</span>
            </a>
            <a href="#" class="btn btn-success btn-sm btn-icon-split" data-toggle="modal" data-target="#customerModal">
                <span class="text">Agregar Cliente</span>
            </a>
            <a href="#" class="btn btn-success btn-sm btn-icon-split">
                <span class="text">Limpiar</span>
            </a>
        </div>
        <div class="card-body">
            <div class="col-lg-7">
                <div class="p-2">
                    <form class="user" method="POST" action="<?php echo e(route('credit.save')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="text" class="form-control " name="fullname" id="fullname"
                                value="<?php echo e(old('fullname')); ?>" placeholder="Nombre Cliente" disabled>
                            <input type="hidden" name="id" id="id" value="">
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6 mb-3 mb-sm-0">
                                <input type="number" class="form-control " name="amount" id="amount"
                                    value="<?php echo e(old('amount')); ?>" placeholder="Valor Prestamo">
                            </div>
                            <div class="col-sm-6">
                                <input type="text" class="form-control " name="total" id="total"
                                    value="<?php echo e(old('total')); ?>" placeholder="Valor a Pagar">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-4 mb-3 mb-sm-0">
                                <input type="number" class="form-control " name="interest" id="interest"
                                    value="<?php echo e(old('interest')); ?>" placeholder="Interes">
                            </div>
                            <div class="col-sm-4 mb-3 mb-sm-0">
                                <input type="number" class="form-control " name="quota_number" id="quota_number"
                                    value="<?php echo e(old('quota_number')); ?>" placeholder="Numero dias">
                            </div>
                            <div class="col-sm-4">
                                <input type="date" class="form-control " name="date" id="date"
                                    value="<?php echo e(date('Y-m-d')); ?>" placeholder="">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block" id="btnSave">Crear Prestamo</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
    <input type="hidden" id="customerget" value="<?php echo e(route('ajaxcustomer.get')); ?>">
<?php $__env->stopSection(); ?>

<div class="modal fade tableCustomer" id="customerModal" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lista de clientes</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nombre</th>
                            <th>Barrio</th>
                            <th>Aciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($customer->id); ?></td>
                                <td><?php echo e($customer->fullname); ?></td>
                                <td><?php echo e($customer->direction); ?></td>
                                <td>
                                    <button class="btn btn-success agregarCliente recuperarBoton" type="button"
                                        id="customer_id" data-id="<?php echo e($customer->id); ?>">Agregar</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/customer.js')); ?>"></script>
    <script src="<?php echo e(asset('js/credit.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\administradorprestamos\resources\views/credit/create.blade.php ENDPATH**/ ?>