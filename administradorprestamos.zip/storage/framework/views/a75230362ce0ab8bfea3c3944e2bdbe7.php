
<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?> <span> <?php echo e(date('Y-m-d')); ?></span>
<?php $__env->stopSection(); ?>
<?php date_default_timezone_set('America/Bogota'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?php echo e(route('amountuser.report')); ?>" class="btn btn-success btn-sm btn-icon-split">
                <span class="text">Reportes</span>
            </a>
        </div>

        <div class="p-2">
            <div class="row">
                <?php $__currentLoopData = $amountsUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 mb-4">
                        <div class="card-body">
                            <?php echo e($amount->user->name); ?>

                            <div class="text-black-50 p-2">
                                <?php echo e($amount->date); ?>

                                <br>Efectivo A Entregar <br><?php echo e(number_format($amount->amount)); ?>

                            </div>
                            <div class="text-black-50 p-2">Saldo sin entregar
                                <br>
                                <?php if($amount->amount_difference < 0): ?>
                                    <spam class="text-danger"><?php echo e(number_format($amount->amount_difference)); ?></spam>
                                <?php else: ?>
                                    <spam class="text-success"><?php echo e(number_format($amount->amount_difference)); ?></spam>
                                <?php endif; ?>

                            </div>
                            <?php if($amount->state == 2): ?>
                                <a href="<?php echo e(route('amountuser.reportdetail', $amount)); ?>"
                                    class="btn btn-warning btn-sm btn-icon-split">
                                    <span class="text" id="btn-confirmcollection" data-userid="<?php echo e($amount->user_id); ?>">Ver
                                        detalles</span>
                                </a>
                            <?php else: ?>
                                <a href="<?php echo e(route('amountuser.confirm', $amount)); ?>"
                                    class="btn btn-success btn-sm btn-icon-split">
                                    <span class="text" id="btn-confirmcollection"
                                        data-userid="<?php echo e($amount); ?>">Confirmar</span>
                                </a>
                            <?php endif; ?>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php if(session('fail')): ?>
        <script>
            Swal.fire({
                title: 'Error',
                text: '<?php echo e(session('fail')); ?>',
                icon: 'error',
                confirmButtonText: 'Cerrar'
            })
        </script>
    <?php elseif(session('success')): ?>
        <script>
            Swal.fire({
                title: '<?php echo e(session('success')); ?>',
                icon: 'success',
                confirmButtonText: 'Cerrar'
            })
        </script>
    <?php endif; ?>
    <script src="<?php echo e(asset('js/amountUser.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\administradorprestamos\resources\views/amountuser/index.blade.php ENDPATH**/ ?>