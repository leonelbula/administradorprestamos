
<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?php echo e(route('amountuser.report')); ?>" class="btn btn-success btn-sm btn-icon-split">
                <span class="text">Volver</span>
            </a>
        </div>
        <div class="card-body">
            <div class="col-lg-9">
                <div class="p-2">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary"><?php echo e(strtoupper($amountuser->user->name)); ?></h6>
                    </div>
                </div>
                <div class="card-body">
                    <ul>
                        <li><?php echo e($amountuser->user->type); ?></li>
                        <li><?php echo e($amountuser->user->email); ?></li>
                        <li></li>
                    </ul>
                    <hr>
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Observacion</h6>
                    </div>
                    <ul>
                        <li><?php echo e($amountuser->details); ?></li>
                    </ul>
                    <hr>
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Informacion</h6>
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>codigo</th>
                                    <th>Valor</th>
                                    <th>Saldo</th>
                                    <th>Fecha</th>

                                </tr>
                            </thead>
                            <tbody>

                                <tr>
                                    <td><?php echo e($amountuser->id); ?></td>
                                    <td><?php echo e($amountuser->amount); ?></td>
                                    <td>
                                    <?php if($amountuser->amount_difference < 0): ?>
                                        <spam class="text-danger">
                                            <?php echo e(number_format($amountuser->amount_difference, 0, '', '.')); ?></spam>
                                    <?php else: ?>
                                        <spam class="text-success"><?php echo e(number_format($amountuser->amount_difference,0, '', '.')); ?></spam>
                                    <?php endif; ?>
                                   
                                    <td><?php echo e($amountuser->date); ?></td>
                                </tr>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\administradorprestamos\resources\views/amountuser/reporteDetail.blade.php ENDPATH**/ ?>