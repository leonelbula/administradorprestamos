
<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('buttom'); ?>
    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
            class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?php echo e(route('user.create')); ?>" class="btn btn-success btn-sm btn-icon-split">
                <span class="text">Nuevo</span>
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>email</th>
                            <th>Aciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($empleado->name); ?></td>
                                <td><?php echo e($empleado->email); ?></td>

                                <td>
                                    <a href="<?php echo e(route('user.edit', $empleado)); ?>" class="btn btn-warning btn-sm">
                                        <i class="fas fa-pencil-alt"></i>
                                    </a>
                                    <form action="<?php echo e(route('user.destroy', $empleado)); ?>" method="post"
                                        style="display: inline">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger btn-sm"><i
                                                class="fas fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php if(session('fail')): ?>
        <script>
            Swal.fire({
                title: 'Cobros ya liquidados',
                text: '<?php echo e(session('fail')); ?>',
                icon: 'error',
                confirmButtonText: 'Cerrar'
            })
        </script>
    <?php elseif(session('success')): ?>
        <script>
            Swal.fire({
                title: '<?php echo e(session('success')); ?>',
                icon: 'success',
                confirmButtonText: 'Cerrar'
            })
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\administradorprestamos\resources\views/personalInfomation/index.blade.php ENDPATH**/ ?>