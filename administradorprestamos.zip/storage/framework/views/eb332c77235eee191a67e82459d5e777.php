
<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('buttom'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?php echo e(route('credit.index')); ?>" class="btn btn-success btn-sm btn-icon-split">
                <span class="text">Volver</span>
            </a>
            <?php if(auth()->user()->type == 'admin'): ?>
            <a href="<?php echo e(route('credit.pdfreportcreditdefeated')); ?>" class="btn btn-info btn-sm btn-icon-split" target="_blank">
                <span class="text">Descargar Reporte</span>
            </a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Codigo</th>
                            <th>Fecha</th>
                            <th>Cliente</th>
                            <th>Valor</th>
                            <th>Saldo</th>
                            <th>Cuotas pendiente</th>
                            <th>Estado</th>
                            <th>Aciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $credits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($credit->balance > 0 && strtotime(date('Y-m-d', time())) > strtotime($credit->customer->credit[0]->expiration_date)): ?>
                                <tr>

                                    <td><?php echo e($credit->id); ?></td>
                                    <td><?php echo e($credit->customer->credit[0]->date); ?></td>
                                    <td><?php echo e($credit->customer->fullname); ?></td>
                                    <td><?php echo e(number_format($credit->amount, 0, '', '.')); ?></td>
                                    <td><?php echo e(number_format($credit->balance, 0, '', '.')); ?></td>
                                    <td><?php echo e($credit->quota_number_pendieng); ?></td>
                                    <td>
                                        <?php if($credit->balance > 0 && strtotime(date('Y-m-d', time())) > strtotime($credit->customer->credit[0]->expiration_date)): ?>
                                            <button class="btn btn-sm btn-danger shadow-sm">vencido</button>
                                    </td>
                                <?php elseif($credit->balance == 0): ?>
                                    <button class="btn btn-sm btn-info shadow-sm">Cancelado</button></td>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-success shadow-sm">Al dia</button></td>
                            <?php endif; ?>
                            <td>
                                <a href="<?php echo e(route('cliente.show', $credit)); ?>" class="btn btn-info btn-sm">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <?php if(auth()->user()->type == 'admin'): ?>
                                    <a href="<?php echo e(route('credit.edit', $credit)); ?>" class="btn btn-warning btn-sm">
                                        <i class="fas fa-pencil-alt"></i>
                                    </a>

                                    <form action="<?php echo e(route('credit.delete', $credit)); ?>" method="post"
                                        style="display: inline">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger btn-sm"><i
                                                class="fas fa-trash"></i></button>
                                    </form>
                                <?php endif; ?>

                            </td>
                            </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\administradorprestamos\resources\views/credit/report.blade.php ENDPATH**/ ?>