
<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('buttom'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">

            <?php if(!isset($state)): ?>
                <a href="#" class="btn btn-success btn-sm btn-icon-split" data-toggle="modal" data-target="#initpayModal">
                    <span class="text">Iniciar Cobros</span>
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('loanpayment.create')); ?>" class="btn btn-success btn-sm btn-icon-split">
                    <span class="text">Nuevo Registro</span>
                </a>
                <a href="#" class="btn btn-primary btn-sm btn-icon-split" data-toggle="modal"
                    data-target="#loanpaycloseModal">
                    <span class="text">Liquidar Cobros</span>
                </a>
            <?php endif; ?>


        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="card shadow mb-3">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Cobros Realizados Total = <?php echo e(count($loanPay)); ?></h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nombre cliente</th>
                                        <th>Aciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 0;
                                    ?>
                                    <?php $__currentLoopData = $customerspays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($pay->fullname); ?></td>
                                            <td>
                                                <a href="" class="btn btn-info btn-sm">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="" class="btn btn-warning btn-sm">
                                                    <i class="fas fa-pencil-alt"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card shadow mb-3">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-success">Cobros Pendiente Total =
                            <?php
                                $saldo = $numPay - count($loanPay);
                            ?>
                            <?php echo e($saldo); ?>

                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Nombre cliente</th>
                                        <th>Direccion</th>
                                        <th>Aciones</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $customersPend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($customer->customer->fullname); ?></td>
                                            <td><?php echo e($customer->customer->direction); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('cliente.show', $customer->customer->id)); ?>"
                                                    class="btn btn-info btn-sm">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>


<div class="modal fade" id="initpayModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Iniciar Cobros del dia</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('amountuser.startPay')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <div class="col-sm-4">
                            <input type="date" class="form-control " name="date" id="date"
                                value="<?php echo e(date('Y-m-d')); ?>" placeholder="">
                        </div>
                        <div class="col-sm-4">
                            <button type="submit" class="btn btn-primary" id="btnInit">Iniciar Cobros</button>
                        </div>
                    </div>

                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
            </div>
        </div>
    </div>
</div>


<div class="modal fade " id="loanpaycloseModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Confirmar Cierre</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="user" method="POST" action="<?php echo e(route('amountuser.saveClose')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="text" class="form-control " name="fullname" id="fullname"
                            value="<?php echo e(auth()->user()->name); ?>" placeholder="Nombre de cobrador" disabled>
                        <input type="hidden" name="id" id="id" value="1">

                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6">
                            <input type="date" class="form-control " name="date" id="date"
                                value="<?php echo e(date('Y-m-d')); ?>" placeholder="">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block" id="Save">Guardar</button>

                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('script'); ?>
    <?php if(session('fail')): ?>
        <script>
            Swal.fire({
                title: 'Cobros ya liquidados',
                text: '<?php echo e(session('fail')); ?>',
                icon: 'error',
                confirmButtonText: 'Cerrar'
            })
        </script>
    <?php elseif(session('success')): ?>
        <script>
            Swal.fire({
                title: '<?php echo e(session('success')); ?>',
                icon: 'success',
                confirmButtonText: 'Cerrar'
            })
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\administradorprestamos\resources\views/loanpayment/index.blade.php ENDPATH**/ ?>